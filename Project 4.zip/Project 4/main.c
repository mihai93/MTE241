#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LPC17xx.h>
#include "GLCD.h"

#define BG	White
#define FG	Magenta
#define FG2	Blue
#define N	50
#define CORNER	5

int main( void ) {
	/*** Declare all variables ***/
	unsigned short square[N];
  int i, j, radius, f, ddF_x, ddF_y, r, c, index; 
	/*** Declare all variables ***/
	
// 	for (i = 0; i<10;i++)
// 		square[i] = FG2;
// 	for (i = 10; i< (N*N)-10; i++)
// 		square[i] = FG;		
// 	for (i = (N*N)-10;i<N*N;i++)
// 		square[i] = FG2;
	
	index = 0;
	
	for (i = 0;i<N;i++)
	{
		for (j = 0;j<N;j++)
		{
			if ((i < CORNER || i >= N - CORNER) && (j < CORNER || j >= N - CORNER))
				square[index] = FG;
			else
				square[index] = FG2;
			
			index++;
		}
	}
	
	radius = N/2;
	f = 1 - radius;
	ddF_x = 0;
	ddF_y = -2 * radius;
	
	SystemInit();
	GLCD_Init();
	GLCD_Clear(BG); 
	GLCD_Bitmap (160-N/2, 120-N/2, N, N, (unsigned char*)square);

  while(1);
}
	